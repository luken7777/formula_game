<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <style>
            ul {
                list-style-type: none;
            }
        </style>
    </head>
    <body>
        <?php require_once './selectFromDatabase.php'; ?>
        <ul>
            <?php for ($i = 0; $i < count($stats); $i++) { ?>
                <li><?php echo $stats[$i] ?></li>
            <?php } ?>
        </ul>
    </body>
</html>
